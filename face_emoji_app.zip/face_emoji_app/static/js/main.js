
const uploadForm = document.getElementById('upload-form');
const uploadResult = document.getElementById('upload-result');
uploadForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fileInput = uploadForm.querySelector('input[name="image"]');
  if (!fileInput.files.length) return;
  const formData = new FormData();
  formData.append('image', fileInput.files[0]);
  const res = await fetch('/process_image', { method: 'POST', body: formData });
  if (res.ok) {
    const blob = await res.blob();
    uploadResult.src = URL.createObjectURL(blob);
  } else {
    alert('Processing failed');
  }
});

// ---------- Live camera ----------
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const cameraResult = document.getElementById('camera-result');
const ctx = canvas.getContext('2d');

async function startCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
    await video.play();
    setInterval(captureAndSend, 600); // capture every 600 ms
  } catch (err) {
    console.error('Camera error:', err);
  }
}

async function captureAndSend() {
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  canvas.toBlob(async (blob) => {
    const formData = new FormData();
    formData.append('frame', blob, 'frame.jpg');
    const res = await fetch('/process_frame', { method: 'POST', body: formData });
    if (res.ok) {
      const outBlob = await res.blob();
      cameraResult.src = URL.createObjectURL(outBlob);
    }
  }, 'image/jpeg', 0.8);
}

startCamera();
