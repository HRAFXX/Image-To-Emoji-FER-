
# Face‑Emoji Replacer

A Python Flask web application that detects faces & emotions in an image (or live webcam)
and replaces each face with an emoji or meme sticker representing the dominant expression.

## How it works

1. **Face detection** – OpenCV deep‑learning SSD model
2. **Emotion recognition** – `FER` library (CNN trained on FER‑2013)
3. **Emoji overlay** – Replaces the face region with a transparent‑background PNG
4. **Web UI** – Upload a photo or use live webcam feed via HTML5

## Quick start

```bash
python -m venv venv
source venv/bin/activate   # or .\venv\Scripts\activate on Windows
pip install -r requirements.txt
python app.py
```

Then browse to <http://127.0.0.1:5000/>

## Add your emoji images

Place 128×128 (or larger) PNGs with transparent background in **static/emojis/**:

```
angry.png
disgust.png
fear.png
happy.png
sad.png
surprise.png
neutral.png
```

Open‑source sets like [OpenMoji](https://openmoji.org) or [Twemoji](https://github.com/twitter/twemoji) work well.

## Notes

* First run will automatically download the face‑detector model (~10 MB) to `models/`.
* Accuracy depends on lighting and camera resolution; try decent lighting for webcam mode.
* To tweak performance, lower the capture interval in `static/js/main.js` or resize frames before processing.
