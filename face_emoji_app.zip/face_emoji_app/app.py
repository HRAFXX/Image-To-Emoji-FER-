
import os
import urllib.request
import cv2
import numpy as np
from fer import FER
from flask import Flask, render_template, request, Response

app = Flask(__name__)

# ----------------------------------------------------------------------
# Model download helpers
# ----------------------------------------------------------------------

MODEL_DIR = os.path.join(app.root_path, "models")
PROTO_PATH = os.path.join(MODEL_DIR, "deploy.prototxt")
WEIGHTS_PATH = os.path.join(MODEL_DIR, "res10_300x300_ssd_iter_140000.caffemodel")

def ensure_face_model():
    """Download OpenCV's face detector if it's not present."""
    os.makedirs(MODEL_DIR, exist_ok=True)
    if not os.path.exists(PROTO_PATH):
        print("Downloading face detector prototxt...")
        urllib.request.urlretrieve(
            "https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt",
            PROTO_PATH,
        )
    if not os.path.exists(WEIGHTS_PATH):
        print("Downloading face detector caffemodel (≈10 MB)...")
        urllib.request.urlretrieve(
            "https://github.com/opencv/opencv_3rdparty/raw/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel",
            WEIGHTS_PATH,
        )

ensure_face_model()

# ----------------------------------------------------------------------
# Load models
# ----------------------------------------------------------------------

print("Loading face detector...")
face_net = cv2.dnn.readNetFromCaffe(PROTO_PATH, WEIGHTS_PATH)

print("Loading emotion detector...")
emotion_detector = FER(mtcnn=True)  # uses MTCNN + a CNN for emotion

# ----------------------------------------------------------------------
# Load emoji images into memory
# ----------------------------------------------------------------------

EMOJI_DIR = os.path.join(app.root_path, "static", "emojis")
# Map FER labels to emoji filenames
EMOJI_MAP = {
    "angry": "angry.png",
    "disgust": "disgust.png",
    "fear": "fear.png",
    "happy": "happy.png",
    "sad": "sad.png",
    "surprise": "surprise.png",
    "neutral": "neutral.png",
}

emoji_cache = {}
for label, filename in EMOJI_MAP.items():
    path = os.path.join(EMOJI_DIR, filename)
    if os.path.exists(path):
        emoji_cache[label] = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    else:
        print(f"[WARN] Emoji file not found for '{label}': {path}")

# ----------------------------------------------------------------------
# Utility functions
# ----------------------------------------------------------------------

def detect_faces(frame, conf_threshold=0.5):
    (h, w) = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(
        frame, 1.0, (300, 300), (104.0, 177.0, 123.0), swapRB=False, crop=False
    )
    face_net.setInput(blob)
    detections = face_net.forward()
    boxes = []
    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence >= conf_threshold:
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            (x1, y1, x2, y2) = box.astype(int)
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w - 1, x2), min(h - 1, y2)
            boxes.append((x1, y1, x2 - x1, y2 - y1))
    return boxes

def overlay_emoji(frame, x, y, w, h, emoji):
    if emoji is None:
        return
    emoji_resized = cv2.resize(emoji, (w, h))
    if emoji_resized.shape[2] == 4:
        # Split out alpha channel
        alpha = emoji_resized[:, :, 3] / 255.0
        rgb = emoji_resized[:, :, :3]
        # Blend
        for c in range(3):
            frame[y : y + h, x : x + w, c] = (
                alpha * rgb[:, :, c] + (1 - alpha) * frame[y : y + h, x : x + w, c]
            )
    else:
        frame[y : y + h, x : x + w] = emoji_resized

def process_frame(frame):
    faces = detect_faces(frame)
    for (x, y, w, h) in faces:
        # Crop & predict emotion
        face_roi = frame[y : y + h, x : x + w]
        emotion, score = emotion_detector.top_emotion(face_roi)
        if emotion is None:
            emotion = "neutral"
        emoji_img = emoji_cache.get(emotion, None)
        overlay_emoji(frame, x, y, w, h, emoji_img)
    return frame

# ----------------------------------------------------------------------
# Flask routes
# ----------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/process_image", methods=["POST"])
def process_image():
    if "image" not in request.files:
        return "No file part", 400
    file = request.files["image"]
    data = file.read()
    nparr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        return "Bad image", 400
    result = process_frame(img)
    _, out_jpg = cv2.imencode(".jpg", result)
    return Response(out_jpg.tobytes(), mimetype="image/jpeg")

@app.route("/process_frame", methods=["POST"])
def process_frame_api():
    if "frame" not in request.files:
        return "No frame", 400
    file = request.files["frame"]
    data = file.read()
    nparr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        return "Bad frame", 400
    result = process_frame(img)
    _, out_jpg = cv2.imencode(".jpg", result)
    return Response(out_jpg.tobytes(), mimetype="image/jpeg")

if __name__ == "__main__":
    app.run(debug=True)
